package devonframe.gyva.admin.system.code.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import devonframe.gyva.admin.contents.survey.model.Survey;
import devonframe.gyva.front.common.code.model.Code;
import devonframe.gyva.front.common.code.service.CodeService;
import devonframe.gyva.front.common.menu.model.Menu;
import devonframe.gyva.front.common.menu.service.MenuService;
/**
 * <pre>
 * 사용자 정보에 대한 CRUD를 담당하는 Controller 클래스
 * </pre>
 *
 * @author XXX팀 OOO
 */

@Controller
public class AdminCodeController {
    
    @Resource(name = "menuService")
    private MenuService menuService;

    @Resource(name = "codeService")
    private CodeService codeService;
    
    @RequestMapping(value="/admin/system/group/retrieveGroupCodeList.do")
    public String retrieveQuestionList(ModelMap model, HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);
    	
    	List<Code> resultList = codeService.retrieveGroupCodeList();
        model.addAttribute("resultList", resultList);
        
        return "admin/system/code/group/list";
    }

    @RequestMapping(value="/admin/system/group/retrieveGroupCodeForm.do") 
    public String retrieveGroupCodeForm(HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);

    	return "admin/system/code/group/write";
    }
    
    @RequestMapping(value="/admin/system/group/retrieveGroupCodeWrite.do")
    public String retrieveGroupCodeWrite(Code input, ModelMap model, HttpSession session){

		input.setUserId((String) session.getAttribute("userId"));

		codeService.insertGroupCode(input);

        return "redirect:/admin/system/group/retrieveGroupCodeList.do?menuId="+session.getAttribute("MenuInfoInterceptor_menuId");
    }

    @RequestMapping(value="/admin/system/group/retrieveGroupCodeDetail.do")
    public String retrieveGroupCodeDetail(Code input, ModelMap model, HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);
		
    	Code result = codeService.retrieveGroupCodeDetail(input);

        model.addAttribute("result", result);

        return "admin/system/code/group/update";
    }
    
	@RequestMapping(value="/admin/system/group/retrieveGroupCodeUpdate.do")
    public String retrieveGroupCodeUpdate(Code input, ModelMap model, HttpSession session){

		input.setUserId((String) session.getAttribute("userId"));

		codeService.updateGroupCode(input);
    	
        return "redirect:/admin/system/group/retrieveGroupCodeList.do?menuId="+session.getAttribute("MenuInfoInterceptor_menuId");
    }
    
    @RequestMapping(value="/admin/system/detail/retrieveDetailCodeList.do")
    public String retrieveDetailList(ModelMap model, HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);
    	
    	List<Code> resultList = codeService.retrieveDetailCodeList();
        model.addAttribute("resultList", resultList);
        
        return "admin/system/code/detail/list";
    }

    @RequestMapping(value="/admin/system/detail/retrieveDetailCodeForm.do") 
    public String retrieveDetailCodeForm(ModelMap model, HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);

    	List<Code> groupCodeList = codeService.retrieveGroupList();   	

        model.addAttribute("groupCodeList", groupCodeList);

    	return "admin/system/code/detail/write";
    }
    
    @RequestMapping(value="/admin/system/detail/retrieveDetailCodeWrite.do")
    public String retrieveDetailCodeWrite(Code input, ModelMap model, HttpSession session){

		input.setUserId((String) session.getAttribute("userId"));

		codeService.insertDetailCode(input);

        return "redirect:/admin/system/detail/retrieveDetailCodeList.do?menuId="+session.getAttribute("MenuInfoInterceptor_menuId");
    }

    @RequestMapping(value="/admin/system/detail/retrieveDetailCodeDetail.do")
    public String retrieveDetailCodeDetail(Code input, ModelMap model, HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);

    	List<Code> groupCodeList = codeService.retrieveGroupList();
    	Code result = codeService.retrieveDetailCodeDetail(input);    	

        model.addAttribute("groupCodeList", groupCodeList);
        model.addAttribute("result", result);

        return "admin/system/code/detail/update";
    }
    
	@RequestMapping(value="/admin/system/detail/retrieveDetailCodeUpdate.do")
    public String retrieveDetailCodeUpdate(Code input, ModelMap model, HttpSession session){

		input.setUserId((String) session.getAttribute("userId"));

		codeService.updateDetailCode(input);
    	
        return "redirect:/admin/system/detail/retrieveDetailCodeList.do?menuId="+session.getAttribute("MenuInfoInterceptor_menuId");
    }
	
}