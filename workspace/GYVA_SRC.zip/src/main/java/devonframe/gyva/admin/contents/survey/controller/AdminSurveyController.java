package devonframe.gyva.admin.contents.survey.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import devonframe.gyva.front.common.code.model.Code;
import devonframe.gyva.front.common.code.service.CodeService;
import devonframe.gyva.admin.contents.survey.model.Survey;
import devonframe.gyva.admin.contents.survey.service.SurveyService;
import devonframe.gyva.front.common.menu.model.Menu;
import devonframe.gyva.front.common.menu.service.MenuService;
import devonframe.paging.model.PagingMap;
import devonframe.paging.policy.annotation.PagingPolicy;
/**
 * <pre>
 * 사용자 정보에 대한 CRUD를 담당하는 Controller 클래스
 * </pre>
 *
 * @author XXX팀 OOO
 */

@Controller
public class AdminSurveyController {
    
    @Resource(name = "menuService")
    private MenuService menuService;

    @Resource(name = "codeService")
    private CodeService codeService;

    @Resource(name = "surveyService")
    private SurveyService surveyService;
    
    /* 문항 등록 */
    @RequestMapping(value="/admin/survey/question/retrieveQuestionList.do")
    public String retrieveQuestionList(@PagingPolicy("policy2")PagingMap pagingMap, ModelMap model, HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);
    		
        List<Survey> resultList = surveyService.retrieveQuestionPagedList(pagingMap);

        model.addAttribute("input", pagingMap.getMap());
        model.addAttribute("resultList", resultList);

        return "admin/contents/survey/question/contentsList";
    }

    @RequestMapping(value="/admin/survey/question/retrieveQuestionForm.do") 
    public String retrieveQuestionForm(){

    	return "admin/contents/survey/question/contentsWrite";
    }
    
    @RequestMapping(value="/admin/survey/question/retrieveQuestionWrite.do")
    public String retrieveQuestionWrite(Survey input, ModelMap model, HttpSession session){

    	String surveyId = surveyService.retrieveSurveyId("survey_id");
    	
    	input.setSurveyId(surveyId);
		input.setUserId((String) session.getAttribute("userId"));

    	surveyService.insertQuestionInfo(input);

        return "redirect:/admin/survey/question/retrieveQuestionList.do?menuId="+session.getAttribute("MenuInfoInterceptor_menuId");
    }

    @RequestMapping(value="/admin/survey/question/retrieveQuestionDetail.do")
    public String retrieveQuestionDetail(Survey input, ModelMap model, HttpSession session){
		
		Survey result = surveyService.retrieveQuestionDetail(input);

        model.addAttribute("result", result);

        return "admin/contents/survey/question/contentsUpdate";
    }
    
	@RequestMapping(value="/admin/survey/question/retrieveQuestionUpdate.do")
    public String retrieveQuestionUpdate(Survey input, ModelMap model, HttpSession session){

		input.setUserId((String) session.getAttribute("userId"));

    	surveyService.updateQuestionInfo(input);
    	
        return "redirect:/admin/survey/question/retrieveQuestionList.do?menuId="+session.getAttribute("MenuInfoInterceptor_menuId");
    }
    
    /* 결과 조회 */
    @RequestMapping(value="/admin/survey/result/retrieveResultList.do")
    public String retrieveResultList(@PagingPolicy("policy2")PagingMap pagingMap, ModelMap model, HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);
    		
        List<Survey> resultList = surveyService.retrieveResultPagedList(pagingMap);

        model.addAttribute("input", pagingMap.getMap());
        model.addAttribute("resultList", resultList);

        return "admin/contents/survey/result/contentsList";
    }
    
    @RequestMapping(value="/admin/survey/question/retrieverResultDetail.do")
    public String retrieverResultDetail(@RequestParam Map<String, Object> input, String mode, ModelMap model, HttpSession session){
		
		Menu menu = new Menu();
		menu.setUserId((String) session.getAttribute("userId"));
		menu.setMenuId((String) session.getAttribute("MenuInfoInterceptor_menuId"));
		
		menuService.insertLog(menu);

        return "admin/contents/survey/result/contentsDetail";
    }
	
}