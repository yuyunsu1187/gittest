package devonframe.gyva.admin.system.log.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import devonframe.dataaccess.CommonDao;
import devonframe.gyva.admin.contents.survey.model.Survey;
import devonframe.paging.model.PagingEntity;

@Service("logService")
public class LogServiceImpl implements LogService{

    @Resource(name = "commonDao")
    private CommonDao commonDao;  

    public List<Survey> retrieveQuestionPagedList(PagingEntity survey) {
        List<Survey> resultList = commonDao.selectPagedList("Survey.retrieveQuestionList", survey);
        return resultList;
    }
    public List<Survey> retrieveResultPagedList(PagingEntity survey) {
        List<Survey> resultList = commonDao.selectPagedList("Survey.retrieveResultList", survey);
        return resultList;
    }    

    public String retrieveSurveyId(String name) {
    	String surveyId = commonDao.select("Survey.retrieveSurveyId", name);
    	return surveyId;
    }
    
    // Question 저장
 	@Override
 	public void insertQuestionInfo(Survey survey) {
 		commonDao.insert("Survey.insertQuestionInfo", survey);
 	}   
 	// Question 수정
 	public void updateQuestionInfo(Survey survey) {
 		commonDao.update("Survey.updateQuestionInfo", survey);
 	} 
    
    // Result 저장
 	@Override
 	public void insertResult(Survey survey) {
 		commonDao.insert("Survey.insertResult", survey);
 	}    
 	// Result 수정
  	@Override
 	public void updateResult(Survey survey) {
  		commonDao.update("Survey.updateResult", survey);
 	} 
    
    public Survey retrieveQuestionInfo(Survey survey) {
        return commonDao.select("Survey.retrieveQuestionInfo", survey);
    }   
    public Survey retrieveResultInfo(Survey survey) {
        return commonDao.select("Survey.retrieveResultInfo", survey);
    }
    
    public Survey retrieveQuestionDetail(Survey survey) {
    	Survey result = commonDao.select("Survey.retrieveQuestionDetail", survey);
        return result;
    }   
    public List<Survey> retrieveResultDetail(Survey survey) {
    	List<Survey> resultList = commonDao.selectList("Survey.retrieveResultDetail", survey);
        return resultList;
    }

}
