package devonframe.gyva.front.contents.service;

import java.util.List;
import devonframe.gyva.front.contents.model.Contents;


public interface ContentsService {

    public Contents retrieveContents(Contents contents);
    
    public List<Contents> retrieveContentsList(Contents contents);
    
}
