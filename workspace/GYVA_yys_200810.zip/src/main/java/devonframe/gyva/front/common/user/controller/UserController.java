package devonframe.gyva.front.common.user.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import devonframe.fileupload.FileUpload;
import devonframe.fileupload.model.UploadFileInfo;
import devonframe.gyva.front.common.fileupload.service.FileUploadService;
import devonframe.gyva.front.common.user.model.User;
import devonframe.gyva.front.common.user.service.UserService;
import devonframe.message.saymessage.SayMessage;

/**
 * <pre>
 * 본 클래스는 사용자 정보에 대한 CRUD를 담당하는 Controller 클래스입니다.
 * </pre>
 *
 * @author XXX팀 OOO
 */

@Controller
public class UserController {

	@Resource(name = "userService")
	private UserService userService;
	
	@Resource(name = "fileUpload")
	private FileUpload fileUpload;
	
	@Resource(name = "fileUploadService")
	private FileUploadService fileUploadService;
	
	// 회원 정보 조회
	@RequestMapping(value="/common/user/retrieveUser.do")
	public String retrieveUser(User input, ModelMap model){
		System.out.println("\t\t\t ################################# retrieveUser start");
		User user = null;

		user = userService.retrieveUser(input);
		System.out.println("user tostring:::["+user.toString()+"]");
		if (user == null) {
			SayMessage.setMessageCode("dev.inf.com.nodata");
		}
		model.addAttribute("result", user);

		System.out.println("\t\t\t ################################# retrieveUser e n d");
		return "common/login/myPageForm";
	}
	
	// 아이디 중복체크
	@ResponseBody
	@RequestMapping(value = "/common/user/idChk.do")
	public int idChk(User input, ModelMap model) {
		System.out.println("\t\t\t ################################# idChk ");
		int result = userService.idChk(input);
		System.out.println("result::::::"+result);
		return result;
	}
	

	// 회원 정보 수정
	@RequestMapping(value = "/common/user/updateUser.do")
	public String updateUser(User input, ModelMap model) {
		System.out.println("\t\t\t ################################# updateUser ");
		userService.updateUser(input);
		return "redirect:/main.do?msg=success";
	}

	// 회원 정보 삭제
	@RequestMapping(value="/common/user/deleteUser.do")
	public String deleteUser(User input, ModelMap model){
		System.out.println("[============================deleteUser]");
		userService.deleteUser(input);
		return "redirect:/common/login/joinForm.do?msg=success";
	}
	
	// 회원 저장
	@RequestMapping(value = "/common/user/insertUser.do")
	public String insertUser(User input, ModelMap model, MultipartHttpServletRequest mpRequest) {
		System.out.println("\t\t\t ################################# insertUser ");
		
		// ID 중복 체크
		int result = userService.idChk(input);

		// 중복 ID가 없을 경우에만 저장
		if(result == 1){
			System.out.println("중복 있음");
			return "/common/login/joinForm";
		} else {
			System.out.println("중복 없음");
										
//			List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
//			list = FileParseService.fileParseList(mpRequest);
			String fildId = getRandomUuid(10);
			input.setFileId(fildId);
			Iterator<String> iterator = mpRequest.getFileNames();
			
			MultipartFile multipartFile = null;
			int fileNumber = 1;
			String fileName = null;
			String uploadFilePath = null;
			String uploadFileName = null;
			long fileSize = 0;
			String fileExtension = null;
			
			List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
			Map<String, Object> listMap = null;
			
			while(iterator.hasNext()) {
				multipartFile = mpRequest.getFile(iterator.next());
				if(multipartFile.isEmpty() == false) {
					UploadFileInfo uploadFileInfo = fileUpload.upload(multipartFile);
					
					fileName = uploadFileInfo.getClientFileName();
					uploadFilePath = uploadFileInfo.getServerPath();
					uploadFileName = uploadFileInfo.getServerFileName();
					fileSize = uploadFileInfo.getSize();
					fileExtension = uploadFileInfo.getClientFileName().substring(uploadFileInfo.getClientFileName().lastIndexOf(".")+1);
					
					try {
						listMap = new HashMap<String, Object>();
						listMap.put("fileId", fildId);
						listMap.put("fileNumber", fileNumber++);
						listMap.put("fileName", fileName);
						listMap.put("uploadFilePath", uploadFilePath);
						listMap.put("uploadFileName", uploadFileName);
						listMap.put("fileSize", fileSize);
						listMap.put("fileExtension", fileExtension);
						list.add(listMap);
						
					} catch (IllegalStateException e) {
						e.printStackTrace();
					}
				}
			}
//					
			// user_info 테이블에 저장
			userService.insertUser(input, list);
		}
		return "redirect:/main.do?msg=success";
	}
	
	/**
	 * 10자리 random UUID생성
	 *
	 * @param length 문자열 길이
	 * @return 랜덤문자열
	 */
	private static String getRandomUuid(int length) {
		String result = "";
		for (int i = 0; i < 5; i++) {
			String uuid = UUID.randomUUID().toString().replaceAll("-", ""); // -를 제거해 주었다.
			uuid = uuid.substring(0, length); // uuid를 앞에서부터 10자리 잘라줌.
//			System.out.println(i + ") " + uuid);
			result = uuid;
		}
		return result;
	}
}