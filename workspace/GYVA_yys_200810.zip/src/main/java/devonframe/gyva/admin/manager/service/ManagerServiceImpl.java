package devonframe.gyva.admin.manager.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import devonframe.gyva.admin.manager.dao.ManagerDao;
import devonframe.gyva.admin.manager.model.Manager;


/**
 * <pre>
 * 관리자 정보에 대한 CRUD를 담당하는 ServiceImpl 클래스
 * </pre>
 *
 * @author XXX팀 OOO
 */
@Service("managerService")
public class ManagerServiceImpl implements ManagerService {

	@Resource(name = "managerDao")
	private ManagerDao managerDao;

	@Override
	public Manager retrieveManager(Manager manager) {
		return managerDao.retrieveManager(manager);
	}

	@Override
	public List<Manager> retrieveManagerList(Manager manager) {
		List<Manager> resultList = managerDao.retrieveManagerList(manager);
		return resultList;
	}

	// 회원 가입
	@Override
	public void insertManager(Manager manager) {
		managerDao.insertManager(manager);
	}
	
	// 회원 정보 수정
	@Override
	public void updateManager(Manager manager) {
		managerDao.updateManager(manager);
	}
	
	// 삭제
	@Override
	public void deleteManager(Manager manager) {
		managerDao.deleteManager(manager);
	}
	
	// 회원 비밀번호 수정
	@Override
	public void resetPwdManager(Manager manager) {
		managerDao.updatePwdManager(manager);
	}

}
