/**
 * 
 */
/**
 * @author goldtree15
 *
 */
package devonframe.gyva.admin.user.model;