package devonframe.gyva.admin.manager.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import devonframe.gyva.admin.manager.model.Manager;
import devonframe.gyva.admin.manager.service.ManagerService;
import devonframe.message.saymessage.SayMessage;

/**
 * <pre>
 * 관리자 정보에 대한 CRUD를 담당하는 Controller 클래스
 * </pre>
 *
 * @author XXX팀 OOO
 */

@Controller
public class ManagerController {

	@Resource(name = "managerService")
	private ManagerService managerService;

	// 관리자 회원 조회
	@RequestMapping(value = "/admin/manager/retrieveManager.do")
	public String retrieveManager(Manager input, ModelMap model) {
		System.out.println("\t\t\t ################################# retrieveManager start");
		Manager manager = null;
		manager = managerService.retrieveManager(input);

		System.out.println("manager toString:::[" + manager.toString() + "]");
		if (manager == null) {
			SayMessage.setMessageCode("dev.inf.com.nodata");
		}

		model.addAttribute("result", manager);
		System.out.println("\t\t\t ################################# retrieveManager e n d");
		return "admin/managerLogin/myPageForm";

	}

	// 관리자 회원 가입
	@RequestMapping(value = "/admin/manager/insertManager.do")
	public String insertManager(Manager input, ModelMap model) {
		System.out.println("\t\t\t ################################# insertManager");
		System.out.println("manager print");
		System.out.println(input);
		managerService.insertManager(input);
		return "redirect:/managerMain.do?msg=success";
	}

	// 관리자 회원 정보 수정
	@RequestMapping(value = "/admin/manager/updateManager.do")
	public String updateManager(Manager input, ModelMap model) {
		System.out.println("\t\t\t ################################# insertManager ");
		managerService.updateManager(input);
		return "redirect:/managerMain.do?msg=success";
	}

	// 관리자 회원 정보 삭제
	@RequestMapping(value = "/admin/manager/deleteManager.do")
	public String deleteManager(Manager input, ModelMap model) {
		System.out.println("[============================deleteManager]");
		managerService.deleteManager(input);
		return "redirect:/admin/managerLogin/joinForm.do?msg=success";
	}
	
	// 관리자 메인 페이지
	@RequestMapping(value = "/managerMain.do")
	public String retrieveMainPage(String redirectUrl, ModelMap model) {
		if (redirectUrl != null && !redirectUrl.trim().equals("")) {
			model.addAttribute("redirectUrl", redirectUrl);
			String menuCode = redirectUrl.substring(0, redirectUrl.indexOf("/"));
			if (redirectUrl.startsWith("/")) {
				menuCode = redirectUrl.substring(1);
				menuCode = menuCode.substring(0, menuCode.indexOf("/"));
			}
			model.addAttribute("menuCode", menuCode);
		}
		return "admin/login/main";
	}
	
	// 관리자 가입 페이지
	@RequestMapping(value = "/admin/managerLogin/joinForm.do")
	public String joinForm(ModelMap model) {
		System.out.println("\t\t\t ################################# joinForm ");
		return "admin/login/joinForm";
	}
	
	// 관리자 수정 페이지
	@RequestMapping(value = "/admin/managerLogin/myPageForm.do")
	public String myPageForm(ModelMap model, HttpSession session) {
		System.out.println("\t\t\t ################################# myPageForm ");
		return "admin/login/myPageForm";
	}
	
	// 관리자 pw 리셋 페이지
	@RequestMapping(value = "/admin/managerLogin/resetPassword.do")
	public String resetPasswordForm(ModelMap model) {
		System.out.println("\t\t\t ################################# ResetPasswordForm ");
		return "admin/login/resetPassword";
	}
}