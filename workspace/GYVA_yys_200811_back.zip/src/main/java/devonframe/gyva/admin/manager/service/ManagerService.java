package devonframe.gyva.admin.manager.service;

import java.util.List;

import devonframe.gyva.admin.manager.model.Manager;

public interface ManagerService {

	public Manager retrieveManager(Manager manager);
	public List<Manager> retrieveManagerList(Manager manager);
	
	public void insertManager(Manager manager);
	public void updateManager(Manager manager);
	public void deleteManager(Manager manager);
	public void resetPwdManager(Manager manager);

}
