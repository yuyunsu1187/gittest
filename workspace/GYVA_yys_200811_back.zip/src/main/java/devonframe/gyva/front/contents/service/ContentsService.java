package devonframe.gyva.front.contents.service;

import java.util.List;
import java.util.Map;

import devonframe.gyva.front.contents.model.Contents;


public interface ContentsService {

	// Contents 조회
    public Contents retrieveContents(Contents contents);
    
    // Contents List 조회
    public List<Contents> retrieveContentsList(Contents contents);

}
