package devonframe.gyva.admin.contents.anatomy.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import devonframe.gyva.front.common.code.model.Code;
import devonframe.gyva.front.common.code.service.CodeService;
import devonframe.gyva.front.common.user.model.User;
import devonframe.gyva.front.common.user.service.UserService;
import devonframe.gyva.front.contents.model.Contents;
import devonframe.gyva.front.contents.service.ContentsService;

@Controller
public class AdminAnatomyContentsController {

    @Resource(name = "contentsService")
    private ContentsService contentsService;
	
	@Resource(name = "codeService")
	private CodeService codeService;
	
	@Resource(name = "userService")
	private UserService userService;
    
    @RequestMapping(value="/admin/contents/anatomy/retrieveContentsList.do")
    public String retrieveContentsList(Contents input, ModelMap model){
    	
    	List<Contents> resultList = contentsService.retrieveContentsList(input);
        model.addAttribute("resultList", resultList);
        
        return "admin/contents/academy/anatomy/contentsList";
    }
    
    @RequestMapping(value="/admin/contents/anatomy/retrieveContents.do")
    public String retrieveContentsDetail(Contents input, ModelMap model){

    	Contents contents = contentsService.retrieveContents(input);
    	
        model.addAttribute("result", contents);

        return "admin/contents/academy/anatomy/contentsDetail";
    }

	// 관리자 Contents 입력 페이지
	@RequestMapping(value = "/admin/contents/academy/anatomy/contentsWrite.do")
	public String contentsAnatomyWrite(Contents input, Code code, ModelMap model, HttpSession session) {

		List<User> resultList = userService.retrieveLecturerList(input);

		String menuId = (String) session.getAttribute("MenuInfoInterceptor_menuId");
		input.setMenuId(menuId);
		
		code.setCodeGroup(menuId);
		List<Code> categoryCodeList = codeService.retrieveCodeList(code);
		String nextContentsId =  contentsService.retrieveNextContentsId(input);
		
		model.addAttribute("resultList", resultList);
		model.addAttribute("categoryCodeList", categoryCodeList);
		model.addAttribute("menuId", menuId);
		model.addAttribute("nextContentsId", nextContentsId);
		return "admin/contents/academy/anatomy/contentsWrite";
	}

	// 강사 정보 조회
	@ResponseBody
	@RequestMapping(value = "/admin/contents/academy/anatomy/retrieveLecturerInfo.do")
	public User retrieveLecturerInfo(User input, ModelMap model) {

		User lecturer = userService.retrieveLecturer(input);
		return lecturer;
	}
    
}
