package devonframe.gyva.front.contents.anatomy.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import devonframe.gyva.front.contents.model.Contents;
import devonframe.gyva.front.contents.service.ContentsService;

@Controller
public class AnatomyContentsController {

    @Resource(name = "contentsService")
    private ContentsService contentsService;
    
    @RequestMapping(value="/contents/anatomy/retrieveContentsList.do")
    public String retrieveContentsList(Contents input, ModelMap model, HttpSession session){
    	
//    	List<Contents> resultList = contentsService.retrieveContentsList(input);
//      model.addAttribute("resultList", resultList);
        
        input.setUserId((String)session.getAttribute("userId"));
        input.setCategoryCode("01");
        List<Contents> upperList = contentsService.retrieveContentsList(input);
        
        input.setCategoryCode("02");
        List<Contents> midList = contentsService.retrieveContentsList(input);
        
        input.setCategoryCode("03");
        List<Contents> lowList = contentsService.retrieveContentsList(input);
        
        model.addAttribute("upperList", upperList);
        model.addAttribute("midList", midList);
        model.addAttribute("lowList", lowList);
        
        return "contents/academy/anatomy/contentsList";
    }
    
    @RequestMapping(value="/contents/anatomy/retrieveContents.do")
    public String retrieveContentsDetail(Contents input, ModelMap model, HttpSession session){
    	
    	input.setUserId((String)session.getAttribute("userId"));
    	Contents contents = contentsService.retrieveContents(input);
    	
        model.addAttribute("result", contents);

        return "contents/academy/anatomy/contentsDetail";
    }
    
    @ResponseBody
	@RequestMapping(value = "/contents/anatomy/updateLikeDislike.do")
	public Contents updateLikeDislike(Contents input, ModelMap model, HttpSession session) {
    	
    	System.out.println("\t\t\t ################################# updateLikeDislike ");
    	input.setUserId((String)session.getAttribute("userId"));
    	System.out.println("before logic input ========== " + input.toString());
    	
    	
    	Contents contents = contentsService.retrieveContents(input);
    	System.out.println("contents.dislikeYn ===== " + contents.getDislikeYn());
    	
    	if (contents.getDislikeYn() != null && contents.getDislikeYn() != "") {   		
    		contentsService.updateLikeDislike(contents);
    	} else {
    		System.out.println("insert logic input ========== " + input.toString());
    		contentsService.insertLikeDislike(input);   		
    	}
    	
    	System.out.println("\t\t\t ### updateLikeDislike END ");
    	contents = contentsService.retrieveContents(input);
		return contents;
	}
}
