package devonframe.gyva.front.common.util;

public interface UtilService {
	
	public String getRandomUuid(int length); 
}
