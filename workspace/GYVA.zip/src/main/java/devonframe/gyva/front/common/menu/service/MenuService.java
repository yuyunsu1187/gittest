package devonframe.gyva.front.common.menu.service;

import devonframe.gyva.front.common.menu.model.Menu;

public interface MenuService {
	
	public void insertLog(Menu menu);;
	
}