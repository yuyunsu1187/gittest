package devonframe.gyva.front.common.fileupload.service;

import devonframe.gyva.front.common.fileupload.model.FileInfo;


public interface FileUploadService {

    public void insertFileInfo(FileInfo fileInfo);
}
