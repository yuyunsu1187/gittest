package devonframe.gyva.front.common.fileupload.service;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import devonframe.dataaccess.CommonDao;
import devonframe.gyva.front.common.fileupload.model.FileInfo;

@Service("fileUploadService")
public class FileUploadServiceImpl implements FileUploadService {
    
    @Resource(name = "commonDao")
    private CommonDao commonDao;

    public void insertFileInfo(FileInfo fileInfo) {
        commonDao.insert("FileInfo.insertFileInfo", fileInfo);
    }

}
