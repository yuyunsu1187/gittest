package com.gyva.web;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.UUID;

import org.junit.Test;

public class PatterTest {

    @Test
    /*public void 특수문자_공백_포함_정규식_테스트() {
    	String str = "특정 문자열 |may| 사이의 |찾기| 문자열 추출하기";
    	String str1 = "yuyunsu@gmail.com";

    			Pattern pattern = Pattern.compile("(.*?)[@]");
    			Pattern pattern2 = Pattern.compile("[@](.*?)");

    			Matcher matcher = pattern.matcher(str1);
    			Matcher matcher2 = pattern2.matcher(str1);
    					
    			while (matcher.find()) {
    			    System.out.println(matcher.group(1).toUpperCase());
    					    		    
    			    if(matcher.group(1) ==  null)
    			    	break;
    			}
    			
    			while (matcher2.find()) {
    			    System.out.println(matcher2.group(1));
    					    		    
    			    if(matcher2.group(1) ==  null)
    			    	break;
    			}
    			
    			
    			// '@'기준 앞쪽은 uppercase 처리 뒤쪽은 그대로 유지
    			System.out.println(str1.indexOf("@"));
    			System.out.println(str1.substring(0,str1.indexOf("@")).toUpperCase());
    			System.out.println(str1.substring(str1.indexOf("@")));
    			System.out.println(str1.toUpperCase());
    			System.out.println(str1.substring(0,str1.indexOf("@")).toUpperCase()+str1.substring(str1.indexOf("@")));
    			
    			
    }*/
    
	/*public void findExtension() {
		String str = "cou.nting_120200.803[1].png";

		// '.'위치 찾아서 그 뒤쪽부터 추출
		System.out.println(str.substring(str.lastIndexOf(".")+1));
	}*/
    
    public void getTimestamp() {
    	 SimpleDateFormat formatter = new SimpleDateFormat ("yyyy-MM-dd hh:mm:ss.SSS");
    	    Calendar cal = Calendar.getInstance();
    	    String today = null;
    	    today = formatter.format(cal.getTime());
    	    Timestamp ts = Timestamp.valueOf(today);
    	    
    	    // 현재시간 밀리 세컨드 System.currentTimeMillis()
    		// '.'위치 찾아서 그 뒤쪽부터 추출
    	    System.out.println( " Timestamp : " + ts);
    	    System.out.println( " Timestamp 2: " + getRandomString());
    	    
    	    
	}
    
    public static String getRandomString() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
}