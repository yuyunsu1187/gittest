package com.gyva.web.common.user.service;

import java.util.List;

import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.gyva.web.common.user.model.User;

public interface UserService {

	public User retrieveUser(User user);
	public List<User> retrieveUserList(User user);
	
	public void insertUser(User user, MultipartHttpServletRequest mpRequest);
	public void updateUser(User user);
	public void deleteUser(User user);
	public void resetPwdUser(User user);
	
	// 아이디 중복체크
	public int idChk(User user);
}
