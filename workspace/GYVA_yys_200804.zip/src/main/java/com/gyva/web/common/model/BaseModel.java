package com.gyva.web.common.model;

public class BaseModel {

	// C,R,U,D
	private String actType;

	public String getActType() {
		return actType;
	}

	public void setActType(String actType) {
		this.actType = actType;
	}

}
