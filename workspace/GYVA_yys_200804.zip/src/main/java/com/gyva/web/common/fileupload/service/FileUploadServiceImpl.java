package com.gyva.web.common.fileupload.service;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.gyva.web.common.fileupload.model.FileInfo;

import devonframe.dataaccess.CommonDao;

@Service("fileUploadService")
public class FileUploadServiceImpl implements FileUploadService {
    
    @Resource(name = "commonDao")
    private CommonDao commonDao;

    public void insertFileInfo(Map<String, Object> map){
    	   commonDao.insert("FileInfo.insertFileInfo", map);
    }

}
