package com.gyva.web.common.filedownload.service;

import java.util.List;

import com.gyva.web.common.filedownload.model.FileInfo;


public interface FileDownloadService {

    public void deleteFileInfoList(List<FileInfo> fileInfoList);
    
    public List<FileInfo> retrieveFileInfoList(FileInfo fileInfo);
    
    
}

